﻿namespace AssignmentThree.Utilities
{
    /// <summary>
    ///  A helper class to Get and  validate the input
    /// </summary>
    public static class ConsoleReader
    {
        private const int MaxTries = 3;

        /// <summary>
        /// To get the name of the product from the user.
        /// </summary>
        /// <param name="name">Contains the name and returned using out parameter</param>
        /// <returns>True - Successfully got the valid Name || False - Cant get the name , out of tries </returns>
        public static bool GetName(out string name)
        {
            int tries = MaxTries;
            do
            {
                tries--;
                Console.WriteLine($"\nEnter the Name of the product");
                name = Console.ReadLine()?.Trim() ?? string.Empty;
                string result = Validator.ValidateName(name);
                if (result == string.Empty)
                {
                    return true;
                }

                ConsolePresenter.DisplayWarningMessage(result);
                ConsolePresenter.DisplayWarningMessage($"Number of Tries Left is:{tries}\n");
            }
            while (tries > 0);
            return false;
        }

        /// <summary>
        /// To get the product Id from the user.
        /// </summary>
        /// <param name="productId">It stores the Id of the product and returns as out parameter</param>
        /// <returns>True - Got the valid product Id || False - Cant get a valid product Id (out of tries)</returns>
        public static bool GetId(out string productId)
        {
            int tries = MaxTries;
            do
            {
                tries--;
                Console.WriteLine($"\nEnter the ID of the Product");
                productId = Console.ReadLine()?.Trim() ?? string.Empty;
                string result = Validator.ValidateId(productId);
                if (result == string.Empty)
                {
                    return true;
                }

                ConsolePresenter.DisplayWarningMessage(result);
                ConsolePresenter.DisplayWarningMessage($"Number of Tries Left is:{tries}\n");
            }
            while (tries > 0);
            return false;
        }

        /// <summary>
        /// To get the Price in the double.
        /// </summary>
        /// <param name="productPrice">Gets and returns a price (out parameter)</param>
        /// <returns>True - Got the valid product price || False - Cant get a valid product price (out of tries)</returns>
        public static bool GetPrice(out double productPrice)
        {
            int tries = MaxTries;
            do
            {
                tries--;
                Console.WriteLine("\nEnter the price:");
                string productPriceAsString = ReadInput();
                string result = Validator.ValidatePrice(productPriceAsString, out productPrice);
                if (result == string.Empty)
                {
                    return true;
                }

                ConsolePresenter.DisplayWarningMessage(result);
                ConsolePresenter.DisplayWarningMessage($"Number of Tries Left is:{tries}\n");
            }
            while (tries > 0);
            return false;
        }

        /// <summary>
        /// To get a number.
        /// </summary>
        /// <param name="number">Number (as out) stores the number</param>
        /// <returns>True - Got the valid number || False - Invalid Number and out of tries</returns>
        public static bool GetNumber(out int number)
        {
            int tries = MaxTries;
            do
            {
                tries--;
                Console.WriteLine("\nEnter the Choice Number:");
                string numberAsString = ReadInput();
                if (int.TryParse(numberAsString, out number))
                {
                    return true;
                }

                ConsolePresenter.DisplayWarningMessage($"The entered value needs to be a number , Tries left {tries}");
            }
            while (tries > 0);

            return false;
        }

        /// <summary>
        /// To get the product Quantity.
        /// </summary>
        /// <param name="productQuantity">Stores Product quantity and returns through as out parameter</param>
        /// <returns>True - Got the valid Quantity || False - Invalid Quantity and out of tries</returns>
        public static bool GetQuantity(out long productQuantity)
        {
            int tries = MaxTries;
            do
            {
                tries--;
                Console.WriteLine("\nEnter the Quantity:");
                string productQuantityAsString = ReadInput();
                string result = Validator.ValidateQuantity(productQuantityAsString, out productQuantity);
                if (result == string.Empty)
                {
                    return true;
                }

                ConsolePresenter.DisplayWarningMessage(result);
                ConsolePresenter.DisplayWarningMessage($"Number of Tries Left is:{tries}\n");
            }
            while (tries > 0);

            return false;
        }

        /// <summary>
        /// Prompt for Yes (Y/y) or No (N/n) response.
        /// </summary>
        /// <param name="shouldProceed">Outputs true if Y/y, false if N/n.</param>
        /// <param name="promptMessage">Message to display to the user.</param>
        /// <returns>True if valid response was given, false if out of tries.</returns>
        public static bool GetYesOrNo(out bool shouldProceed, string promptMessage)
        {
            shouldProceed = false;
            int tries = MaxTries;
            do
            {
                tries--;
                Console.Write($"{promptMessage} (y/n): ");
                string input = ReadInput().ToLower();
                if (input == "y" || input == "yes")
                {
                    shouldProceed = true;
                    return true;
                }

                if (input == "n" || input == "no")
                {
                    shouldProceed = false;
                    return true;
                }

                ConsolePresenter.DisplayWarningMessage($"Invalid input! Enter 'y' or 'n'. Tries left: {tries}");
            }
            while (tries > 0);

            return false;
        }

        /// <summary>
        /// Reads a line from the console and strips all control characters like (^A, ^B, ^c...)
        /// </summary>
        /// <returns>Input string without control characters.</returns>
        private static string ReadInput()
        {
            string input = Console.ReadLine()?.Trim() ?? string.Empty;

            // return input.Trim();
            return new string(input.Where(c => !char.IsControl(c)).ToArray()).Trim();
        }
    }
}